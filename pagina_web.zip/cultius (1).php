<div class="section">
    <h2>Cultius (versió debug)</h2>

    <!-- Formulari per afegir nou cultiu -->
    <div class="form-section">
        <h3>Afegir nou cultiu</h3>
        <form method="post">
            <input type="hidden" name="p" value="cultius">
            <input type="hidden" name="nou_cultiu" value="1">

            <label>Nom comú:</label>
            <input type="text" name="nom_comu" required placeholder="ex: Poma">

            <label>Nom científic:</label>
            <input type="text" name="nom_cientific" placeholder="ex: Malus domestica">

            <button type="submit" class="btn">Afegir cultiu (prova)</button>
        </form>
    </div>

    <!-- Missatge de debug -->
    <?php
    echo '<pre style="background:#eee;padding:10px;border:1px solid #ccc;">';
    echo "POST rebuts:\n";
    print_r($_POST);
    echo '</pre>';

    // Intent de guardat amb missatges clars
    if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['nou_cultiu'])) {
        echo '<div style="background:#ffeb3b;padding:15px;margin:20px 0;border:2px solid #f57c00;">DEBUG: S\'ha detectat POST nou_cultiu!</div>';

        $nom_comu = trim($_POST['nom_comu'] ?? '');
        if ($nom_comu) {
            $stmt = $conn->prepare("INSERT INTO Cultiu (nom_comu) VALUES (?)");
            $stmt->bind_param("s", $nom_comu);
            if ($stmt->execute()) {
                echo '<div style="background:#4caf50;color:white;padding:15px;margin:20px 0;">ÈXIT: Cultiu guardat (nom: ' . htmlspecialchars($nom_comu) . ')</div>';
            } else {
                echo '<div style="background:#f44336;color:white;padding:15px;margin:20px 0;">ERROR MySQL: ' . $stmt->error . '</div>';
            }
            $stmt->close();
        } else {
            echo '<div style="background:#f44336;color:white;padding:15px;margin:20px 0;">ERROR: Nom comú obligatori</div>';
        }
    } else {
        echo '<div style="background:#ff9800;color:white;padding:15px;margin:20px 0;">DEBUG: No s\'ha rebut POST nou_cultiu</div>';
    }
    ?>

    <!-- Llistat bàsic -->
    <?php
    $cultius = $conn->query("SELECT id_cultiu, nom_comu FROM Cultiu ORDER BY nom_comu");
    if ($cultius->num_rows > 0):
    ?>
        <h3>Cultius existents</h3>
        <table>
            <tr><th>ID</th><th>Nom comú</th></tr>
            <?php while ($c = $cultius->fetch_assoc()): ?>
                <tr>
                    <td><?= $c['id_cultiu'] ?></td>
                    <td><?= htmlspecialchars($c['nom_comu']) ?></td>
                </tr>
            <?php endwhile; ?>
        </table>
    <?php else: ?>
        <p>No hi ha cultius encara.</p>
    <?php endif; ?>
</div>
