<div class="section">
    <h2>Personal</h2>

    <!-- Formulari per afegir nou treballador -->
    <div class="form-section">
        <h3>Afegir nou treballador</h3>
        <form method="post">
            <input type="hidden" name="p" value="personal">
            <input type="hidden" name="nou_treballador" value="1">

            <label>NIF:</label>
            <input type="text" name="nif" required placeholder="ex: 12345678Z">

            <label>Nom:</label>
            <input type="text" name="nom" required>

            <label>Cognoms:</label>
            <input type="text" name="cognoms" required>

            <label>Telèfon:</label>
            <input type="text" name="telefon" placeholder="ex: 600 123 456">

            <button type="submit" class="btn">Afegir treballador</button>
        </form>
    </div>

    <!-- Formulari per registrar absència -->
    <div class="form-section">
        <h3>Registrar absència</h3>
        <form method="post">
            <input type="hidden" name="p" value="personal">
            <input type="hidden" name="nou_absencia" value="1">

            <label>Treballador:</label>
            <select name="id_treballador" required>
                <option value="">Selecciona treballador</option>
                <?php
                $treballadors = $conn->query("SELECT id_treballador, CONCAT(nom, ' ', cognoms) AS nom_complet FROM Treballador ORDER BY cognoms, nom");
                while ($t = $treballadors->fetch_assoc()) {
                    echo '<option value="' . $t['id_treballador'] . '">' . htmlspecialchars($t['nom_complet']) . '</option>';
                }
                ?>
            </select>

            <label>Tipus d'absència:</label>
            <select name="tipus" required>
                <option value="Vacances">Vacances</option>
                <option value="Malaltia">Malaltia</option>
                <option value="Permís">Permís</option>
                <option value="Altres">Altres</option>
            </select>

            <label>Data inici:</label>
            <input type="date" name="data_inici" required>

            <label>Data fi (opcional):</label>
            <input type="date" name="data_fi">

            <label>Document justificatiu (opcional):</label>
            <input type="text" name="document_justificatiu" placeholder="ex: Certificat mèdic, document...">

            <button type="submit" class="btn">Registrar absència</button>
        </form>
    </div>

    <!-- Llistat de treballadors -->
    <h3>Llistat de treballadors</h3>
    <?php
    $treballadors = $conn->query("SELECT * FROM Treballador ORDER BY cognoms, nom");
    if ($treballadors->num_rows > 0):
    ?>
        <table>
            <tr>
                <th>ID</th>
                <th>NIF</th>
                <th>Nom complet</th>
                <th>Telèfon</th>
            </tr>
            <?php while ($t = $treballadors->fetch_assoc()): ?>
                <tr>
                    <td><?= $t['id_treballador'] ?></td>
                    <td><?= htmlspecialchars($t['nif']) ?></td>
                    <td><?= htmlspecialchars($t['nom'] . ' ' . $t['cognoms']) ?></td>
                    <td><?= htmlspecialchars($t['telefon'] ?? '-') ?></td>
                </tr>
            <?php endwhile; ?>
        </table>
    <?php else: ?>
        <p>Encara no hi ha treballadors registrats.</p>
    <?php endif; ?>

    <!-- Llistat d'absències -->
    <h3>Llistat d'absències</h3>
    <?php
    $absencies = $conn->query("
        SELECT a.id_absencia, t.nom, t.cognoms, a.tipus, a.data_inici, a.data_fi, a.aprovada, a.document_justificatiu
        FROM Absencia a
        JOIN Treballador t ON a.id_treballador = t.id_treballador
        ORDER BY a.data_inici DESC
    ");

    if ($absencies->num_rows > 0):
    ?>
        <table>
            <tr>
                <th>ID</th>
                <th>Treballador</th>
                <th>Tipus</th>
                <th>Data inici</th>
                <th>Data fi</th>
                <th>Aprovada</th>
                <th>Document justificatiu</th>
            </tr>
            <?php while ($a = $absencies->fetch_assoc()): ?>
                <tr>
                    <td><?= $a['id_absencia'] ?></td>
                    <td><?= htmlspecialchars($a['nom'] . ' ' . $a['cognoms']) ?></td>
                    <td><?= htmlspecialchars($a['tipus']) ?></td>
                    <td><?= htmlspecialchars($a['data_inici']) ?></td>
                    <td><?= htmlspecialchars($a['data_fi'] ?? '-') ?></td>
                    <td><?= $a['aprovada'] ? 'Sí' : 'No' ?></td>
                    <td><?= htmlspecialchars($a['document_justificatiu'] ?? '-') ?></td>
                </tr>
            <?php endwhile; ?>
        </table>
    <?php else: ?>
        <p>Encara no hi ha absències registrades.</p>
    <?php endif; ?>
</div>
