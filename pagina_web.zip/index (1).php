<?php
session_start();

ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

// Connexió
$conn = new mysqli("localhost", "root", "", "Projecte");
if ($conn->connect_error) {
    die("Error de connexió: " . $conn->connect_error);
}
$conn->set_charset("utf8mb4");

// Pestanya activa
$p = $_GET['p'] ?? 'home';

// ────────────────────────────────────────────────
// PROCESSAMENT POST – AQUÍ VAN TOTS ELS FITXERS
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $p = $_POST['p'] ?? 'home';

    // PERSONAL – Nou treballador
    if (isset($_POST['nou_treballador'])) {
        $nif     = trim($_POST['nif'] ?? '');
        $nom     = trim($_POST['nom'] ?? '');
        $cognoms = trim($_POST['cognoms'] ?? '');
        $telefon = trim($_POST['telefon'] ?? '');

        if ($nif && $nom && $cognoms) {
            $stmt = $conn->prepare("INSERT INTO Treballador (nif, nom, cognoms, telefon) VALUES (?, ?, ?, ?)");
            $stmt->bind_param("ssss", $nif, $nom, $cognoms, $telefon);
            $stmt->execute();
            $stmt->close();
            $_SESSION['msg'] = "Treballador afegit correctament!";
        } else {
            $_SESSION['err'] = "NIF, nom i cognoms són obligatoris";
        }
    }

    // PERSONAL – Nova absència
    if (isset($_POST['nou_absencia'])) {
        $id_treballador = (int)($_POST['id_treballador'] ?? 0);
        $tipus          = trim($_POST['tipus'] ?? '');
        $data_inici     = $_POST['data_inici'] ?? null;
        $data_fi        = $_POST['data_fi'] ?? null;
        $aprovada       = 0; // per defecte no aprovada
        $document_justificatiu = trim($_POST['document_justificatiu'] ?? '');

        if ($id_treballador > 0 && $tipus && $data_inici) {
            $stmt = $conn->prepare("
                INSERT INTO Absencia 
                (id_treballador, tipus, data_inici, data_fi, aprovada, document_justificatiu)
                VALUES (?, ?, ?, ?, ?, ?)
            ");
            $stmt->bind_param("isssis", $id_treballador, $tipus, $data_inici, $data_fi, $aprovada, $document_justificatiu);
            $stmt->execute();
            $stmt->close();
            $_SESSION['msg'] = "Absència registrada correctament!";
        } else {
            $_SESSION['err'] = "Treballador, tipus i data inici són obligatoris";
        }
    }

    // PRODUCTE (mantinc el que funcionava)
    if (isset($_POST['nou_producte'])) {
        $nom_comercial     = trim($_POST['nom_comercial'] ?? '');
        $tipus             = trim($_POST['tipus'] ?? '');
        $dosi_recomanada   = trim($_POST['dosi_recomanada'] ?? '');
        $termini_seguretat = (int)($_POST['termini_seguretat'] ?? 0);
        $compatibilitat    = trim($_POST['compatibilitat'] ?? '');
        $numero_registre   = trim($_POST['numero_registre'] ?? '');
        $quantitat_minima  = (float)($_POST['quantitat_minima'] ?? 10.00);

        if ($nom_comercial && $tipus && $dosi_recomanada) {
            $stmt = $conn->prepare("
                INSERT INTO Producte 
                (nom_comercial, tipus, dosi_recomanada, termini_seguretat, compatibilitat, numero_registre, quantitat_minima)
                VALUES (?, ?, ?, ?, ?, ?, ?)
            ");
            $stmt->bind_param("sssissi", $nom_comercial, $tipus, $dosi_recomanada, $termini_seguretat, $compatibilitat, $numero_registre, $quantitat_minima);
            $stmt->execute();
            $stmt->close();
            $_SESSION['msg'] = "Producte afegit correctament!";
        } else {
            $_SESSION['err'] = "Nom comercial, tipus i dosi recomanada obligatoris";
        }
    }

    // ESTOC (mantinc el que funcionava)
    if (isset($_POST['nou_estoc'])) {
        $id_producte       = (int)($_POST['id_producte'] ?? 0);
        $quantitat_disp    = (float)($_POST['quantitat_disponible'] ?? 0);
        $unitat_mesura     = trim($_POST['unitat_mesura'] ?? '');
        $data_compra       = !empty($_POST['data_compra']) ? $_POST['data_compra'] : null;
        $proveidor         = trim($_POST['proveidor'] ?? '');
        $numero_lot        = trim($_POST['numero_lot'] ?? '');
        $data_caducitat    = !empty($_POST['data_caducitat']) ? $_POST['data_caducitat'] : null;
        $ubicacio_magatzem = trim($_POST['ubicacio_magatzem'] ?? '');

        if ($id_producte > 0 && $quantitat_disp > 0 && $unitat_mesura) {
            $stmt = $conn->prepare("
                INSERT INTO Estoc 
                (id_producte, quantitat_disponible, unitat_mesura, data_compra, proveidor, numero_lot, data_caducitat, ubicacio_magatzem)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?)
            ");
            $stmt->bind_param("idssssss", $id_producte, $quantitat_disp, $unitat_mesura, $data_compra, $proveidor, $numero_lot, $data_caducitat, $ubicacio_magatzem);
            $stmt->execute();
            $stmt->close();
            $_SESSION['msg'] = "Entrada d'estoc afegida correctament!";
        } else {
            $_SESSION['err'] = "Producte, quantitat i unitat de mesura obligatoris";
        }
    }

    // SENSOR (mantinc el que funcionava)
    if (isset($_POST['nou_sensor'])) {
        $id_sector       = (int)($_POST['id_sector'] ?? 0);
        $tipus_sensor    = trim($_POST['tipus_sensor'] ?? '');
        $ubicacio        = trim($_POST['ubicacio'] ?? '');
        $data_instalacio = $_POST['data_instalacio'] ?? null;
        $lectures        = trim($_POST['lectures'] ?? '');

        if ($id_sector > 0 && $tipus_sensor && $ubicacio && $data_instalacio) {
            $stmt = $conn->prepare("
                INSERT INTO Sensor 
                (id_sector, tipus_sensor, ubicacio, data_instalacio, lectures)
                VALUES (?, ?, ?, ?, ?)
            ");
            $stmt->bind_param("issss", $id_sector, $tipus_sensor, $ubicacio, $data_instalacio, $lectures);
            $stmt->execute();
            $stmt->close();
            $_SESSION['msg'] = "Sensor afegit correctament!";
        } else {
            $_SESSION['err'] = "Sector, tipus, ubicació i data instal·lació obligatoris";
        }
    }

    // ALERTA MANUAL (mantinc el que funcionava)
    if (isset($_POST['nou_alerta'])) {
        $id_sector            = (int)($_POST['id_sector'] ?? 0) ?: null;
        $tipus_alerta         = trim($_POST['tipus_alerta'] ?? '');
        $nivell_urgencia      = $_POST['nivell_urgencia'] ?? 'Mitjà';
        $missatge             = trim($_POST['missatge'] ?? '');
        $canal_notificacio    = trim($_POST['canal_notificacio'] ?? 'Web');
        $id_usuari_destinatari = (int)($_POST['id_usuari_destinatari'] ?? 0) ?: null;

        if ($tipus_alerta && $missatge) {
            $stmt = $conn->prepare("
                INSERT INTO Alerta 
                (id_sector, tipus_alerta, nivell_urgencia, missatge, canal_notificacio, id_usuari_destinatari)
                VALUES (?, ?, ?, ?, ?, ?)
            ");
            $stmt->bind_param("issssi", $id_sector, $tipus_alerta, $nivell_urgencia, $missatge, $canal_notificacio, $id_usuari_destinatari);
            $stmt->execute();
            $stmt->close();
            $_SESSION['msg'] = "Alerta creada correctament!";
        } else {
            $_SESSION['err'] = "Tipus d'alerta i missatge obligatoris";
        }
    }

    // Redirecció FINAL (només una vegada al final)
    header("Location: index.php?p=$p");
    exit;
}

// ────────────────────────────────────────────────
// Missatges
$msg = $_SESSION['msg'] ?? '';
$err = $_SESSION['err'] ?? '';
unset($_SESSION['msg'], $_SESSION['err']);
?>

<!DOCTYPE html>
<html lang="ca">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>High Elo</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/sweetalert2@11/dist/sweetalert2.min.css">
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
    <style>
        /* El teu CSS habitual */
        body {font-family:system-ui,sans-serif;background:#f8fafc;color:#1e293b;margin:0;padding:0;}
        .container {max-width:1400px;margin:0 auto;padding:20px;}
        .navbar {background:#166534;color:white;padding:20px;text-align:center;border-radius:0 0 15px 15px;margin-bottom:30px;}
        .navbar h1 {margin:0;font-size:2.5rem;}
        .nav-menu {display:flex;justify-content:center;gap:40px;margin-top:15px;flex-wrap:wrap;}
        .nav-menu a {color:white;text-decoration:none;font-weight:600;font-size:1.2rem;cursor:pointer;padding:8px 16px;border-radius:8px;}
        .nav-menu a:hover, .nav-menu a.active {background:#15803d;}
        .section {background:white;border-radius:12px;box-shadow:0 4px 20px rgba(0,0,0,0.1);padding:25px;margin-bottom:30px;}
        table {width:100%;border-collapse:collapse;margin:20px 0;}
        table th, table td {padding:12px;border-bottom:1px solid #ddd;text-align:left;}
        table th {background:#166534;color:white;}
        .form-section {background:#f0fdf4;padding:25px;border-radius:12px;margin-bottom:30px;}
        .btn {background:#16a34a;color:white;border:none;padding:10px 20px;border-radius:8px;cursor:pointer;font-weight:600;}
        .btn:hover {background:#15803d;}
        .msg {background:#d1fae5;color:#065f46;padding:15px;border-radius:10px;margin:20px 0;text-align:center;font-weight:600;}
        .err {background:#fee2e2;color:#991b1b;padding:15px;border-radius:10px;margin:20px 0;text-align:center;font-weight:600;}
        input, select, textarea {width:100%;padding:10px;margin:8px 0 16px;border:1px solid #ccc;border-radius:6px;box-sizing:border-box;}
    </style>
</head>
<body>

<div class="container">
    <nav class="navbar">
        <h1>High Elo</h1>
        <div class="nav-menu">
            <a href="?p=home" class="<?= $p === 'home' ? 'active' : '' ?>">Inici</a>
            <a href="?p=cultius" class="<?= $p === 'cultius' ? 'active' : '' ?>">Cultius</a>
            <a href="?p=personal" class="<?= $p === 'personal' ? 'active' : '' ?>">Personal</a>
            <a href="?p=productes" class="<?= $p === 'productes' ? 'active' : '' ?>">Productes</a>
            <a href="?p=sensors" class="<?= $p === 'sensors' ? 'active' : '' ?>">Sensors / Alertes</a>
        </div>
    </nav>

    <?php if ($msg): ?>
        <div class="msg"><?= htmlspecialchars($msg) ?></div>
    <?php endif; ?>

    <?php if ($err): ?>
        <div class="err"><?= htmlspecialchars($err) ?></div>
    <?php endif; ?>

    <?php if ($p === 'home'): ?>
        <div class="section">
            <h2 style="text-align:center;color:#166534;margin-bottom:30px;">Benvingut a High Elo</h2>
        </div>
    <?php else: ?>
        <?php
        switch ($p) {
            case 'cultius':
                include 'cultius.php';
                break;
            case 'personal':
                include 'personal.php';
                break;
            case 'productes':
                include 'productes.php';
                break;
            case 'sensors':
                include 'sensors.php';
                break;
            default:
                echo '<div class="section"><h2>Pestanya no trobada</h2></div>';
                break;
        }
        ?>
    <?php endif; ?>
</div>

</body>
</html>
