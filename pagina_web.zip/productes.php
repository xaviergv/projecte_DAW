<div class="section">
    <h2>Productes i Estoc</h2>

    <?php
    // ────────────────────────────────────────────────
    // ALERTES AUTOMÀTIQUES PER ESTOC BAIX – NOMÉS UNA PER PRODUCTE
    // ────────────────────────────────────────────────
    $check_estoc = $conn->query("
        SELECT 
            p.id_producte, 
            p.nom_comercial, 
            p.quantitat_minima,
            COALESCE(SUM(e.quantitat_disponible), 0) AS estoc_total
        FROM Producte p
        LEFT JOIN Estoc e ON p.id_producte = e.id_producte
        GROUP BY p.id_producte
        HAVING estoc_total < p.quantitat_minima 
           AND p.quantitat_minima > 0
    ");

    while ($prod = $check_estoc->fetch_assoc()) {
        $nom = $prod['nom_comercial'];
        $estoc = $prod['estoc_total'];
        $min = $prod['quantitat_minima'];

        // Anti-duplicats: només crea si no n'hi ha cap (independentment de l'estat)
        $existeix = $conn->query("
            SELECT COUNT(*) FROM Alerta 
            WHERE tipus_alerta = 'Estoc baix'
              AND missatge LIKE '%$nom%'
        ")->fetch_row()[0];

        if ($existeix == 0) {
            $missatge = "ALERTA AUTOMÀTICA: El producte '$nom' té només " . number_format($estoc, 2) . " unitats disponibles (mínim recomanat: $min). Compra més aviat!";

            $stmt = $conn->prepare("
                INSERT INTO Alerta 
                (tipus_alerta, nivell_urgencia, missatge, canal_notificacio, estat)
                VALUES ('Estoc baix', 'Alt', ?, 'Web', 'Pendent')
            ");
            $stmt->bind_param("s", $missatge);
            $stmt->execute();
            $stmt->close();
        }
    }
    ?>

    <!-- Formulari per afegir producte -->
    <div class="form-section">
        <h3>Afegir nou producte</h3>
        <form method="post">
            <input type="hidden" name="p" value="productes">
            <input type="hidden" name="nou_producte" value="1">

            <label>Nom comercial:</label>
            <input type="text" name="nom_comercial" required>

            <label>Tipus:</label>
            <select name="tipus" required>
                <option value="">Selecciona tipus</option>
                <option value="Fertilitzant">Fertilitzant</option>
                <option value="Insecticida">Insecticida</option>
                <option value="Fungicida">Fungicida</option>
                <option value="Herbicida">Herbicida</option>
            </select>

            <label>Dosi recomanada:</label>
            <input type="text" name="dosi_recomanada" required placeholder="ex: 2 kg/ha">

            <label>Quantitat mínima recomanada (per alertes):</label>
            <input type="number" name="quantitat_minima" step="0.01" min="0" value="10" required>

            <button type="submit" class="btn">Afegir producte</button>
        </form>
    </div>

    <!-- Formulari per afegir estoc -->
    <div class="form-section">
        <h3>Afegir estoc</h3>
        <form method="post">
            <input type="hidden" name="p" value="productes">
            <input type="hidden" name="nou_estoc" value="1">

            <label>Producte:</label>
            <select name="id_producte" required>
                <option value="">Selecciona producte</option>
                <?php
                $products = $conn->query("SELECT id_producte, nom_comercial FROM Producte ORDER BY nom_comercial");
                while ($pr = $products->fetch_assoc()) {
                    echo '<option value="' . $pr['id_producte'] . '">' . htmlspecialchars($pr['nom_comercial']) . '</option>';
                }
                ?>
            </select>

            <label>Quantitat disponible:</label>
            <input type="number" name="quantitat_disponible" step="0.01" min="0" required>

            <label>Unitat de mesura:</label>
            <input type="text" name="unitat_mesura" required placeholder="ex: kg, L">

            <button type="submit" class="btn">Afegir estoc</button>
        </form>
    </div>

    <!-- Llistat bàsic (pots ampliar-lo amb més camps) -->
    <h3>Llistat de productes i estoc</h3>
    <?php
    $products = $conn->query("
        SELECT p.id_producte, p.nom_comercial, p.tipus, p.quantitat_minima,
               COALESCE(SUM(e.quantitat_disponible), 0) AS estoc_total
        FROM Producte p
        LEFT JOIN Estoc e ON p.id_producte = e.id_producte
        GROUP BY p.id_producte
        ORDER BY p.nom_comercial
    ");

    if ($products->num_rows > 0):
    ?>
        <table>
            <tr>
                <th>Nom</th>
                <th>Tipus</th>
                <th>Estoc actual</th>
                <th>Mínim recomanat</th>
            </tr>
            <?php while ($pr = $products->fetch_assoc()): ?>
                <tr>
                    <td><?= htmlspecialchars($pr['nom_comercial']) ?></td>
                    <td><?= htmlspecialchars($pr['tipus']) ?></td>
                    <td><?= number_format($pr['estoc_total'], 2) ?></td>
                    <td><?= number_format($pr['quantitat_minima'], 2) ?></td>
                </tr>
            <?php endwhile; ?>
        </table>
    <?php else: ?>
        <p>Encara no hi ha productes.</p>
    <?php endif; ?>
</div>
