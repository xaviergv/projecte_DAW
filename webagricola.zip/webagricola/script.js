// Show/Hide sections
function showSection(sectionId) {
  // Hide all sections
  const sections = document.querySelectorAll(".section")
  sections.forEach((section) => {
    section.classList.remove("active")
  })

  // Remove active from all nav links
  const navLinks = document.querySelectorAll(".nav-link")
  navLinks.forEach((link) => {
    link.classList.remove("active")
  })

  // Show selected section
  const selectedSection = document.getElementById(sectionId)
  if (selectedSection) {
    selectedSection.classList.add("active")
  }

  // Add active to clicked nav link
  event.target.classList.add("active")
}

// Show/Hide tabs
function showTab(tabId) {
  // Hide all tab contents
  const tabContents = document.querySelectorAll(".tab-content")
  tabContents.forEach((content) => {
    content.classList.remove("active")
  })

  // Remove active from all tab buttons
  const tabButtons = document.querySelectorAll(".tab-button")
  tabButtons.forEach((button) => {
    button.classList.remove("active")
  })

  // Show selected tab
  const selectedTab = document.getElementById(tabId)
  if (selectedTab) {
    selectedTab.classList.add("active")
  }

  // Add active to clicked tab button
  event.target.classList.add("active")
}

// Search functionality
document.addEventListener("DOMContentLoaded", () => {
  const searchParceles = document.getElementById("searchParceles")
  const searchEstoc = document.getElementById("searchEstoc")

  if (searchParceles) {
    searchParceles.addEventListener("keyup", function () {
      filterParceles(this.value)
    })
  }

  if (searchEstoc) {
    searchEstoc.addEventListener("keyup", function () {
      filterEstoc(this.value)
    })
  }

  // Show home section by default
  showSection("home")
})

function filterParceles(searchTerm) {
  const cards = document.querySelectorAll(".parcel-card")
  cards.forEach((card) => {
    const text = card.textContent.toLowerCase()
    card.style.display = text.includes(searchTerm.toLowerCase()) ? "block" : "none"
  })
}

function filterEstoc(searchTerm) {
  const rows = document.querySelectorAll(".data-table tbody tr")
  rows.forEach((row) => {
    const text = row.textContent.toLowerCase()
    row.style.display = text.includes(searchTerm.toLowerCase()) ? "table-row" : "none"
  })
}
